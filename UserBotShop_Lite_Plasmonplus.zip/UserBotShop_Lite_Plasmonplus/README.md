# UserBotShop Lite

Questa è una versione *lite* del nostro UserBotShop: uno script per Telegram che automatizza i comandi base per la gestione del tuo business.

## Comandi inclusi:
- `.ping` → Test di connessione
- `.help` → Guida ai comandi base
- `.listproducts` → Mostra i prodotti

---

🔒 Vuoi la versione completa con:
- Ordini PayPal automatici
- Broadcast clienti
- Statistiche incasso
- Spammer intelligente
- Sistema ordini e conferme

💬 Contattaci su Telegram → [@plasmonplus](https://t.me/plasmonplus)
